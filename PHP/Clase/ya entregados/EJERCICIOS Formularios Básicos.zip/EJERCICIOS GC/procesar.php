<?php
echo "<h2>Información GET:</h2>";
print_r($_GET);
echo "<h2>Información POST:</h2>";
print_r($_POST);
echo "<h2>Información REQUEST:</h2>";
print_r($_REQUEST);
