
    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        print_r($_FILES);
    }
    ?>
