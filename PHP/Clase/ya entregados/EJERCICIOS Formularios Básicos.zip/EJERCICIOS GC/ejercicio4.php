<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario con múltiples botones de envío</title>
</head>

<body>
    <form action="procesar_formulario.php" method="post">

        <input type="submit" name="boton1" value="Enviar Botón 1">
        <input type="submit" name="boton2" value="Enviar Botón 2">
    </form>
</body>

</html>